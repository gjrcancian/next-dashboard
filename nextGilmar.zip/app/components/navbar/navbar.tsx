import React from 'react';
import { renderToNodeStream } from 'react-dom/server';
import styled,{ ServerStyleSheet} from 'styled-components';
import Link from 'next/link';

const NavStyled = styled.nav`
  color:green;
`;

const Heading = styled.h1`
  color: red;
`;

const sheet = new ServerStyleSheet();
const jsx = sheet.collectStyles(<Heading>Hello SSR!</Heading>);
const stream = sheet.interleaveWithNodeStream(renderToNodeStream(jsx));


export default function Navbar() {
  return (
    <NavStyled  className='navbar'>
      
      <Link href="/sobre">Sobre</Link>
      <Link href="/contato">Contato</Link>
    </NavStyled>
  );
}

