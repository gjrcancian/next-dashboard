import React from 'react';
import Navbar from './components/navbar/navbar'

export default function Home() {
  return (
    
    <main className='main' >
           
      
          <Navbar />  

          <div  className='app'>
            sadsad
          </div>






    </main>

  )
  
}
